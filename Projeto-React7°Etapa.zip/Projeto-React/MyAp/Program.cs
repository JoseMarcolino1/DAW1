using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);

// Configuração do CORS
builder.Services.AddCors();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

// Habilitar o CORS
app.UseCors(builder => builder
    .AllowAnyOrigin() // Permitir solicitações de qualquer origem
    .AllowAnyMethod() // Permitir solicitações de qualquer método (GET, POST, PUT, etc.)
    .AllowAnyHeader()); // Permitir solicitações com qualquer cabeçalho

// Rota para receber dados do formulário
app.MapPost("/formulario", async (HttpContext httpContext) =>
{
    // Ler e desserializar dados do corpo da requisição
    var requestBody = await new System.IO.StreamReader(httpContext.Request.Body).ReadToEndAsync();
    var formData = JsonSerializer.Deserialize<FormData>(requestBody, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

    // Validar os dados do formulário

    // Se os dados forem válidos, retornar os dados recebidos
    await httpContext.Response.WriteAsJsonAsync(formData);
});


app.Run();


// Classe para representar os dados do formulário
public class FormData
{
    public int Codigo { get; set; }
    public string Nome { get; set; }
    public string Cpf { get; set; }
    public bool Booleano { get; set; }
    public string Contato { get; set; }
    public string OpcaoSelect { get; set; }
    public string OpcaoRadio { get; set; }

}
