import React from "react";
import Pg2 from "./Pg2";
import Home from "./Home";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

const AppRoutes = () => {
    return(
        <Router>
            <Routes>
                <Route path="/" element={<Home/>}></Route>

                <Route path="/pg2" element={<Pg2/>}></Route>
            </Routes>
        </Router>
    )
}
export default AppRoutes;