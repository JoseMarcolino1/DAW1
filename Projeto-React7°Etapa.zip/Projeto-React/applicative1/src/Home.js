import React, { useState } from 'react';
import axios from 'axios';

function Home() {
  const [formData, setFormData] = useState({
    codigo: null,
    nome: "",
    cpf: "",
    booleano: false,
    contato: "",
    opcaoSelect: "",
    opcaoRadio: ""
  });
  const [responseMessage, setResponseMessage] = useState("");
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : type === 'number' ? parseInt(value) : value;
    setFormData(prevState => ({
      ...prevState,
      [name]: newValue
    }));

    // Validar campos
    const validationErrors = validate({ ...formData, [name]: newValue });
    setErrors(validationErrors);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validar campos
    const validationErrors = validate(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      const response = await axios.post('http://localhost:5171/formulario', formData);
      setResponseMessage(JSON.stringify(response.data));
    } catch (error) {
      console.error(error);
    }
  };

  const validate = (data) => {
    let errors = {};

    if (!data.nome || data.nome.length < 2 || data.nome.length > 255) {
      errors.nome = "Nome obrigatório e deve ter entre 2 e 255 caracteres.";
    }

    if (data.codigo === null || data.codigo <= 0 || data.codigo >= 1000) {
      errors.codigo = "Código obrigatório e deve ser maior que 0 e menor que 1000.";
    }
    if (!data.contato || data.contato.length < 2 || data.contato.length > 255) {
      errors.contato = "Contato obrigatório e deve ter entre 2 e 255 caracteres.";
    }

    if (!data.cpf || data.cpf.length !== 14) {
      errors.cpf = "CPF inválido";
    }

    if (!data.opcaoSelect) {
      errors.opcaoSelect = "Selecione uma opção do dropdown.";
    }

    if (!data.opcaoRadio) {
      errors.opcaoRadio = "Selecione uma opção nos botões de rádio.";
    }

    return errors;
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>
          Código:
          <input type="number" name="codigo" value={formData.codigo || ''} onChange={handleChange} />
          {errors.codigo && <span>{errors.codigo}</span>}
        </label>
        <br />
        <label>
          Nome:
          <input type="text" name="nome" value={formData.nome} onChange={handleChange} />
          {errors.nome && <span>{errors.nome}</span>}
        </label>
        <br />
        <label>
          CPF:
          <input type="text" name="cpf" value={formData.cpf} onChange={handleChange} />
          {errors.cpf && <span>{errors.cpf}</span>}
        </label>
        <br />
        <label>
          Contato:
          <input type="text" name="contato" value={formData.contato} onChange={handleChange} />
          {errors.contato && <span>{errors.contato}</span>}
        </label>
        <br />
        <label>
          Opção Select (Tipo Sanguíneo):
          <select name="opcaoSelect" value={formData.opcaoSelect} onChange={handleChange}>
            <option value="">Selecione o tipo sanguíneo...</option>
            <option value="A">A</option>
            <option value="B">B</option>
            <option value="AB">AB</option>
            <option value="O">O</option>
          </select>
          {errors.opcaoSelect && <span>{errors.opcaoSelect}</span>}
        </label>
        <br />
        <label>
          Opção Radio (RH):
          <label>
            <input type="radio" name="opcaoRadio" value="+" checked={formData.opcaoRadio === "+"} onChange={handleChange} />
            RH+
          </label>
          <label>
            <input type="radio" name="opcaoRadio" value="-" checked={formData.opcaoRadio === "-"} onChange={handleChange} />
            RH-
          </label>
          {errors.opcaoRadio && <span>{errors.opcaoRadio}</span>}
        </label>
        <label>
          <br></br>
          Ativo:
          <input type="checkbox" name="booleano" checked={formData.booleano} onChange={handleChange} />
          {errors.booleano && <span>{errors.booleano}</span>}
        </label>
        <br />
        <button type="submit">Cadastrar</button>
      </form>
      {responseMessage && <p>{responseMessage}</p>}
    </div>
  );
}

export default Home;
