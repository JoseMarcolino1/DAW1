import React, { useState } from 'react';
import axios from 'axios';
import {  } from "react-router-dom";

function Pg2(){
    return(
        <h1>OLÁ</h1>
    );
}

export default Pg2;