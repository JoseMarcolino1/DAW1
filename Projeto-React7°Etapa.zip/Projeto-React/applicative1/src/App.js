import React, { useState } from 'react';
import axios from 'axios';
import AppRoutes from './Routes';
function App() {
  return(
    <div>
      <AppRoutes/>
    </div>
  );
}

export default App;
